This is playable in TA:K Switcher, If you can play those files put these files in the appropriate folder.... 
If you are using TA:K switcher put these files in your races folder.

I hate ReadMes